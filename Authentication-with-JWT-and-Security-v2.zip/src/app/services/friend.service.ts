import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators'

import { HeaderService } from 'src/app/services/header.service';
import { AppConfig } from 'src/app/config/app.config';
import { Friend } from 'src/app/models/friend.model';
import { ToastService } from 'src/app/services/toast.service';

@Injectable({
  providedIn: 'root'
})
export class FriendService {
  apiBaseURL = AppConfig.settings.apiServer.baseURL;
  constructor(private http: HttpClient, private header: HeaderService, private toastService: ToastService) { }

  getAllFriendRequests() {
    return this.http.get<any[]>(this.apiBaseURL + 'friends/');
}
}
