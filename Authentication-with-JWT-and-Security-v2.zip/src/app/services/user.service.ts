import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { User } from 'src/app/models/user.model';
import { HeaderService } from 'src/app/services/header.service';  
import { AppConfig } from 'src/app/config/app.config';


@Injectable({
  providedIn: 'root'
})
export class UserService {

  apiBaseURL = AppConfig.settings.apiServer.baseURL;

  constructor(private http: HttpClient, private header: HeaderService) {
   
  }

  register(newUser: User) {
    return this.http.post<User>(this.apiBaseURL + 'users/register', newUser, this.header.requestHeaders())
      .pipe(res => {
        return res;
      });
  }

  getUserByEmail(email: String): any {
    return this.http.post(this.apiBaseURL + 'users/finduserbyemail', { email: email }, this.header.requestHeaders())
      .pipe(res => {
        return res;
      });
  };
}
