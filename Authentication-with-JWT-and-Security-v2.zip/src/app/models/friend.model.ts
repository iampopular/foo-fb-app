export class Friend {
    id: string;
    userId: string;
    friendId: string;
    status: string;
}
