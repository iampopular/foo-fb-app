export const environment = {
  production: false,
  name: 'development'
};
